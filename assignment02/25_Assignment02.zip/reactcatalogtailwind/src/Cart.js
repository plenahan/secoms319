import {cart} from './Shopping.js'

function Cart() {
    return (
      <div>
        cart
      </div>
    );
  }
  
  export default Cart;
  